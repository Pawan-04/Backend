const express = require('express')
const authController= require('../controllers/auth.controller.js')



const router = express.Router();
///api/auth/register
router.post('/register',authController.registerUser)