// db file
const mongoose = require('mongoose')

async function connectDB(){
   try{
    await mongoose.connect('mongodb+srv://ppawankumar8382_db_user:fQ3yOgunmjazrc6o@cluster0.bzcfq5j.mongodb.net/auth')
    console.log("db is connected")
   }

   catch(error){
    console.log(error)
   }
}

module.exports = connectDB