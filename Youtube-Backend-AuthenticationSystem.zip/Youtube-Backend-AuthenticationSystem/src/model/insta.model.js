const mongoose = require('mongoose')

const instaSchema = new mongoose.Schema({
    userName: String,
    email : String,
})

const model = mongoose.model('insta',instaSchema)

