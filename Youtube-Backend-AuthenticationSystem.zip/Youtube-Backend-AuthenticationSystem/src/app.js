// server creation file
const express = require('express');
const model = require('./model/insta.model.js')
const authRoutes = require('./routes/auth.routes')

const app = express()

app.use(express.json())
app.use('/api/auth',authRoutes)




module.exports = app