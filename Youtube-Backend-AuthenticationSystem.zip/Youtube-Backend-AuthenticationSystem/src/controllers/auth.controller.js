const model = require('../model/insta.model')
const jwt = require("jsonwebtoken")

const JWT_SECRET = '4199fe82afa541d6c3c852f8992da35364d92292bc4c2441895566090f50b5af'

async function registerUser(res,req){

    const {userName, email} = req.body;

    const user = await userModel.create({
        userName,email
    })
    const token = jwt.sign({id: user.__id},JWT_SECRET)

    res.status(201).json({
        message:"User registered successfully",
        user,
        token
    })


}

module.exports = {registerUser}

